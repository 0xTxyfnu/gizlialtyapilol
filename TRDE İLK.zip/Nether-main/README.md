# Nether
Nether is a discord bot for all sorts of purposes
